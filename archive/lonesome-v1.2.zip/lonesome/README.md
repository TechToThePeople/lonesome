#Find contacts without groups or without tags

Some contacts are greated, but not assigned to any group nor any tags. It most likely means that nothing is ever going to happen to them, as most of the targetting is done via groups (eg. in CiviMail).

This extension provides a custom search to let you find your individual contacts that:
- don't belong to a group
- aren't tagged at all
- don't belong to any group nor have any tag

Because no man is an island.
     
